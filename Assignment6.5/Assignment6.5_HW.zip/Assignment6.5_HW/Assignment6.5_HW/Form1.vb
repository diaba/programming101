﻿Public Class Form1
    'fixed Price of pritzel
    Const constPwithCheese = 5
    Const constPwithoutCheese = 2.5

    'Accumulate total
    Dim decAccTotal As Decimal                ' Accumulate total sale 

    Dim intAccNPWithCheese As Integer
    Dim intAccNPWithoutCheese As Integer

    Private Sub BtnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Declare variables
        Dim intNumPWithCheese As Integer                ' Number of pretzel with cheese
        Dim intNumPWithoutCheese As Integer             ' Number of pretzel without cheese

        Dim decTotal As Decimal                   ' Total sale


        'Get Inputs
        intNumPWithCheese = txtNPWithCheese.Text
        intNumPWithoutCheese = txtNPWithoutCheese.Text

        'Calculations
        decTotal = intNumPWithCheese * constPwithCheese + intNumPWithoutCheese * constPwithoutCheese
        decAccTotal = decAccTotal + decTotal
        intAccNPWithCheese = intAccNPWithCheese + intNumPWithCheese
        intAccNPWithoutCheese = intAccNPWithoutCheese + intNumPWithoutCheese

        'Display output
        lblTotSale.Text = FormatCurrency(decTotal)
        lblAccTotal.Text = FormatCurrency(decAccTotal)
        lblAccNWithCheese.Text = intAccNPWithCheese
        lblAccuNWithoutCheese.Text = intAccNPWithoutCheese
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNPWithCheese.Clear()
        txtNPWithoutCheese.Clear()
        lblTotSale.ResetText()
        txtNPWithCheese.Focus()

    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()

    End Sub
End Class
